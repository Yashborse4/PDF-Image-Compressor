"""Offscreen tests for annotating in MARKUP mode (A2).

Highlight / comment / callout now work WITHOUT edit mode; content edits stay
inert until edit mode. These are the positive counterparts to the inertness
tests in test_ui_edit_mode.py.
"""

from __future__ import annotations

import pytest

pytest.importorskip("PySide6")

from pdfapp.main_window import MainWindow  # noqa: E402
from pdfapp.page_coords import page_to_scene  # noqa: E402
from pdfcore.textselect import region_rects  # noqa: E402


def _markup_view(window, path):
    """Open a document and leave it in the default MARKUP mode (no edit)."""
    window.open_path(path)
    view = window.active_view
    view._canvas.resize(800, 600)
    return view


def _span(view, text):
    return next(s for s in view.document.text_spans(0) if s.text.strip() == text)


def _scene_center(view, bbox):
    cx = (bbox[0] + bbox[2]) / 2
    cy = (bbox[1] + bbox[3]) / 2
    return page_to_scene(
        cx,
        cy,
        render_zoom=view._canvas.render_zoom,
        rotation=view.document.page_rotation(0),
        page_size_pts=view.document.page_size(0),
    )


def _sp(view, px, py):
    return page_to_scene(
        px,
        py,
        render_zoom=view._canvas.render_zoom,
        rotation=view.document.page_rotation(0),
        page_size_pts=view.document.page_size(0),
    )


def _annot_count(view, page=0):
    return len(list(view.document._doc[page].annots()))


def _select_span(view, span):
    """Drive an X4 marquee selection over a span's words."""
    x0, y0, x1, y1 = span.bbox
    view._on_select_drag_started(*_sp(view, x0 - 2, y0 - 2))
    view._on_text_select_finished(*_sp(view, x1 + 2, y1 + 2))


# --- highlight ----------------------------------------------------------------


def test_highlight_region_commits_in_markup(qapp, quote_pdf):
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        assert view.edit_mode is False
        span = _span(view, quote_pdf.price)
        z = view._canvas.render_zoom
        rot = view.document.page_rotation(0)
        size = view.document.page_size(0)
        x0, y0, x1, y1 = span.bbox
        s0 = page_to_scene(x0 - 1, y0 - 1, render_zoom=z, rotation=rot, page_size_pts=size)
        s1 = page_to_scene(x1 + 1, y1 + 1, render_zoom=z, rotation=rot, page_size_pts=size)

        view._on_region_selected(s0[0], s0[1], s1[0], s1[1])
        assert _annot_count(view) >= 1  # highlight landed
        assert view.undo_stack.count() == 1
        assert view.dirty

        view.undo_stack.undo()
        assert _annot_count(view) == 0  # non-destructive, fully reversed
    finally:
        window.close()


def test_highlight_span_via_dispatch_in_markup(qapp, quote_pdf):
    """The markup context menu's 'Highlight this text' dispatch works in markup."""
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        span = _span(view, quote_pdf.price)
        view._highlight_rect(0, span.bbox)
        assert _annot_count(view) >= 1
        assert view.undo_stack.count() == 1
    finally:
        window.close()


# --- text-selection highlighting (A3) -----------------------------------------


def test_highlight_the_text_selection(qapp, quote_pdf):
    """A marquee text selection + the Highlight action highlights the selection
    (one annot per selected line), clears it, and is undoable."""
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        span = _span(view, quote_pdf.price)
        _select_span(view, span)
        assert view.has_text_selection()
        n_rects = len(region_rects(view._text_selection))
        assert n_rects >= 1

        window.highlight_text()  # a selection is present → highlight it now
        assert not view.has_text_selection()  # cleared after the mutation
        assert _annot_count(view) == n_rects
        assert view.undo_stack.count() == 1

        view.undo_stack.undo()
        assert _annot_count(view) == 0
    finally:
        window.close()


def test_armed_click_highlights_only_the_word(qapp, tmp_path):
    """With the highlight tool armed, a click / double-click on a word highlights
    exactly that WORD, not the whole line/span under it."""
    import pymupdf

    src = tmp_path / "line.pdf"
    doc = pymupdf.open()
    doc.new_page().insert_text((72, 100), "alpha beta gamma", fontsize=12)
    doc.save(str(src))
    doc.close()

    window = MainWindow()
    try:
        view = _markup_view(window, src)
        beta = next(w for ln in view.document.text_lines(0) for w in ln if w.text == "beta")
        cx = (beta.bbox[0] + beta.bbox[2]) / 2
        cy = (beta.bbox[1] + beta.bbox[3]) / 2

        window.highlight_text()  # no selection → arms the highlight tool
        assert view.armed_action == "highlight"
        s = _sp(view, cx, cy)
        view._canvas.regionSelected.emit(s[0], s[1], s[0], s[1])  # a click (zero drag)

        page = view.document._doc[0]  # keep the page alive — annots orphan otherwise
        annots = list(page.annots())
        assert len(annots) == 1
        xs = [p[0] for p in annots[0].vertices]
        # Hugs "beta" only — not "alpha beta gamma".
        assert min(xs) >= beta.bbox[0] - 2.0
        assert max(xs) <= beta.bbox[2] + 2.0
    finally:
        window.close()


def test_highlight_action_without_selection_arms_marquee(qapp, quote_pdf):
    """With no selection the Highlight action falls back to the area marquee."""
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        assert not view.has_text_selection()
        window.highlight_text()
        assert view.armed_action == "highlight"  # kept the area-drag path
    finally:
        window.close()


def test_triple_click_highlights_line_replacing_word(qapp, tmp_path):
    """A triple-click highlights the whole LINE, replacing the word the first
    click marked — one clean undo step for the gesture."""
    import pymupdf

    src = tmp_path / "line.pdf"
    doc = pymupdf.open()
    doc.new_page().insert_text((72, 100), "alpha beta gamma", fontsize=12)
    doc.save(str(src))
    doc.close()

    window = MainWindow()
    try:
        view = _markup_view(window, src)
        beta = next(w for ln in view.document.text_lines(0) for w in ln if w.text == "beta")
        cx = (beta.bbox[0] + beta.bbox[2]) / 2
        cy = (beta.bbox[1] + beta.bbox[3]) / 2
        s = _sp(view, cx, cy)
        window.highlight_text()  # arm the highlighter

        # Click 1 → the word.
        view._canvas._region_click_count = 1
        view._canvas.regionSelected.emit(s[0], s[1], s[0], s[1])
        assert view.undo_stack.count() == 1
        page = view.document._doc[0]
        word_xs = [p[0] for p in list(page.annots())[0].vertices]
        word_w = max(word_xs) - min(word_xs)

        # Triple-click at the same spot → the whole line, REPLACING the word.
        view._canvas._region_click_count = 3
        view._canvas.regionSelected.emit(s[0], s[1], s[0], s[1])
        assert view.undo_stack.count() == 1  # replaced (not a 2nd annotation)
        page = view.document._doc[0]
        annots = list(page.annots())
        assert len(annots) == 1
        line_xs = [p[0] for p in annots[0].vertices]
        assert (max(line_xs) - min(line_xs)) > word_w + 10  # spans the whole line

        view.undo_stack.undo()  # one undo clears the whole triple gesture
        assert len(list(view.document._doc[0].annots())) == 0
    finally:
        window.close()


def test_highlighter_is_sticky(qapp, quote_pdf):
    """The highlighter STAYS armed after each mark (until Esc / re-trigger)."""
    from PySide6.QtCore import QEvent, QPointF, Qt
    from PySide6.QtGui import QMouseEvent

    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        canvas = view._canvas
        window.highlight_text()  # arm the sticky highlighter
        assert canvas.region_armed

        span = _span(view, quote_pdf.price)
        s = _sp(view, (span.bbox[0] + span.bbox[2]) / 2, (span.bbox[1] + span.bbox[3]) / 2)
        pos = QPointF(canvas.mapFromScene(QPointF(s[0], s[1])))
        canvas.mousePressEvent(
            QMouseEvent(
                QEvent.Type.MouseButtonPress,
                pos,
                Qt.MouseButton.LeftButton,
                Qt.MouseButton.LeftButton,
                Qt.KeyboardModifier.NoModifier,
            )
        )
        canvas.mouseReleaseEvent(
            QMouseEvent(
                QEvent.Type.MouseButtonRelease,
                pos,
                Qt.MouseButton.LeftButton,
                Qt.MouseButton.NoButton,
                Qt.KeyboardModifier.NoModifier,
            )
        )
        assert canvas.region_armed  # still armed after highlighting
        assert view.armed_action == "highlight"

        view.cancel_armed_mode()  # Esc / re-trigger turns it off
        assert not canvas.region_armed
    finally:
        window.close()


def test_region_click_counter_counts_a_triple(qapp, quote_pdf):
    """Press + double-click + press near the same spot reaches count 3 (line)."""
    from PySide6.QtCore import QEvent, QPointF, Qt
    from PySide6.QtGui import QMouseEvent

    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        canvas = view._canvas
        window.highlight_text()
        span = _span(view, quote_pdf.price)
        s = _sp(view, (span.bbox[0] + span.bbox[2]) / 2, (span.bbox[1] + span.bbox[3]) / 2)
        pos = QPointF(canvas.mapFromScene(QPointF(s[0], s[1])))

        def press(kind):
            canvas_evt = QMouseEvent(
                kind,
                pos,
                Qt.MouseButton.LeftButton,
                Qt.MouseButton.LeftButton,
                Qt.KeyboardModifier.NoModifier,
            )
            if kind == QEvent.Type.MouseButtonPress:
                canvas.mousePressEvent(canvas_evt)
            else:
                canvas.mouseDoubleClickEvent(canvas_evt)

        press(QEvent.Type.MouseButtonPress)  # click 1
        assert canvas.region_click_count == 1
        press(QEvent.Type.MouseButtonDblClick)  # click 2
        assert canvas.region_click_count == 2
        press(QEvent.Type.MouseButtonPress)  # click 3
        assert canvas.region_click_count == 3
    finally:
        window.close()


def test_highlight_selection_applies_current_colour(qapp, quote_pdf):
    """The view's highlighter colour reaches the annotation end to end."""
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        view.set_highlight_color((1.0, 0.0, 0.0))
        _select_span(view, _span(view, quote_pdf.price))
        window.highlight_text()
        annot = next(view.document._doc[0].annots())
        assert annot.colors["stroke"] == pytest.approx((1.0, 0.0, 0.0), abs=0.02)
    finally:
        window.close()


# --- comment lifecycle in markup ----------------------------------------------


def _place_comment(view, text, at=(200.0, 400.0)):
    z = view._canvas.render_zoom
    view.begin_insert_comment()
    view._canvas.insertPointSelected.emit(at[0] * z, at[1] * z)
    view._para_editor.setPlainText(text)
    view._para_editor._commit()
    return view.document.comments(0)[0]


def test_comment_placed_and_edited_in_markup(qapp, quote_pdf):
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        comment = _place_comment(view, "note one")
        assert view.edit_mode is False  # still markup
        assert len(view.document.comments(0)) == 1

        # Double-click edits it (markup floats on top).
        view._on_point_activated(*_scene_center(view, comment.rect))
        assert not view._para_editor.isHidden()
        view._para_editor.setPlainText("note two")
        view._para_editor._commit()
        assert view.document.comments(0)[0].text == "note two"
    finally:
        window.close()


def test_comment_moved_and_deleted_in_markup(qapp, quote_pdf):
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        comment = _place_comment(view, "drag + delete me")
        z = view._canvas.render_zoom
        cx, cy = comment.rect[0] + 5.0, comment.rect[1] + 5.0

        # A plain first press selects a comment AND accepts the move drag.
        view._on_select_drag_started(cx * z, cy * z)
        assert view._selection is not None and view._selection[0] == "comment"
        assert view._move_comment is not None
        view._on_move_drag_finished(cx * z, cy * z, cx * z, (cy + 60.0) * z)
        moved = view.document.comments(0)[0]
        assert moved.rect[1] > comment.rect[1]  # moved down

        # Delete removes it (markup).
        view._selection = ("comment", 0, moved)
        view._on_delete_selection()
        assert view.document.comments(0) == []
    finally:
        window.close()


def test_markup_click_away_deselects_comment(qapp, quote_pdf):
    """A click off a selected comment deselects it, so a later Delete doesn't
    silently remove it (review finding — Markup parity with edit mode)."""
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        comment = _place_comment(view, "keep me")
        z = view._canvas.render_zoom
        cx, cy = comment.rect[0] + 5.0, comment.rect[1] + 5.0
        view._on_select_drag_started(cx * z, cy * z)  # select the comment
        view._on_move_drag_finished(cx * z, cy * z, cx * z, cy * z)  # release, no move
        assert view._selection is not None and view._selection[0] == "comment"

        view._on_select_drag_started(*_sp(view, 550.0, 30.0))  # click blank space
        assert view._selection is None
        view._on_delete_selection()  # nothing selected → no-op
        assert len(view.document.comments(0)) == 1
    finally:
        window.close()


def test_selecting_comment_clears_marquee_selection(qapp, quote_pdf):
    """Clicking a comment clears an active marquee text selection (review
    finding — otherwise Highlight would target the stale selection)."""
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        comment = _place_comment(view, "note")
        _select_span(view, _span(view, quote_pdf.price))
        assert view.has_text_selection()

        z = view._canvas.render_zoom
        cx, cy = comment.rect[0] + 5.0, comment.rect[1] + 5.0
        view._on_select_drag_started(cx * z, cy * z)
        assert not view.has_text_selection()
        assert view._selection[0] == "comment"
    finally:
        window.close()


def test_reading_comment_then_entering_edit_mode_adds_no_command(qapp, quote_pdf):
    """Opening a comment editor to READ it (no edits) then switching to Edit
    mode must not recreate the comment or dirty the doc (review finding)."""
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        comment = _place_comment(view, "read-only note")
        count_before = view.undo_stack.count()  # the Add command

        view._on_point_activated(*_scene_center(view, comment.rect))  # double-click to read
        assert not view._para_editor.isHidden()
        view.set_edit_mode(True)  # commits the open editor — unchanged, so no-op
        assert view.undo_stack.count() == count_before
    finally:
        window.close()


def test_callout_two_click_in_markup(qapp, quote_pdf):
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        z = view._canvas.render_zoom
        view.begin_insert_callout()
        view._canvas.insertPointSelected.emit(120 * z, 300 * z)  # target
        assert view.armed_action == "callout_box"
        view._canvas.insertPointSelected.emit(260 * z, 420 * z)  # box
        view._para_editor.setPlainText("what is this line item?")
        view._para_editor._commit()
        comments = view.document.comments(0)
        assert len(comments) == 1
        assert comments[0].kind == "callout"
    finally:
        window.close()


# --- content stays inert in markup --------------------------------------------


def test_content_edits_inert_in_markup(qapp, quote_pdf, sample_png, monkeypatch):
    window = MainWindow()
    try:
        view = _markup_view(window, quote_pdf.path)
        monkeypatch.setattr(view, "_prompt_image_path", lambda: sample_png)
        span = _span(view, quote_pdf.price)

        # Double-click on plain text selects a word (X4), never opens an editor.
        view._on_point_activated(*_scene_center(view, span.bbox))
        assert view._editor.isHidden()
        assert view._para_editor.isHidden()
        assert view._text_selection is not None  # a word got selected instead

        # Content insert/delete dispatch is inert in markup.
        view.begin_insert_text()
        assert view._click_action is None
        view._insert_text_at_point(300.0, 400.0)
        assert view._para_editor.isHidden()
        para = view.document.paragraph_at(
            0, (span.bbox[0] + span.bbox[2]) / 2, (span.bbox[1] + span.bbox[3]) / 2
        )
        view._delete_paragraph_at(0, para)
        assert view.undo_stack.count() == 0  # nothing mutated
    finally:
        window.close()
